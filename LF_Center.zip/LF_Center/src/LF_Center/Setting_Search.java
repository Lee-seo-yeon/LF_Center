package LF_Center;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Setting_Search {
	private JFrame frame;
	private JTextField textoname;
	private JTextField textplace;
	private JTextField textname;
	private JLabel labelSearch;
	private JButton buttonOk;
	private JButton btnReturn;
	
	public Setting_Search() {
		initialize();
	}

	private void initialize() {
		db d1 = new db();
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 255, 224));
		frame.getContentPane().setLayout(null);

		JLabel labelname = new JLabel("\uC77C\uB828\uBC88\uD638 :");
		labelname.setBounds(76, 150, 129, 52);
		labelname.setHorizontalAlignment(SwingConstants.CENTER);
		labelname.setFont(new Font("��������", Font.PLAIN, 20));
		frame.getContentPane().add(labelname);

		textname = new JTextField();
		textname.setBounds(200, 150, 479, 41);
		textname.setFont(new Font("Dialog", Font.PLAIN, 17));
		textname.setColumns(10);
		frame.getContentPane().add(textname);

		JLabel labeloname = new JLabel("\uC8FC\uC778\uC774\uB984 : ");
		labeloname.setBounds(76, 238, 129, 52);
		labeloname.setHorizontalAlignment(SwingConstants.CENTER);
		labeloname.setFont(new Font("Dialog", Font.PLAIN, 20));
		frame.getContentPane().add(labeloname);

		textoname = new JTextField();
		textoname.setBounds(200, 245, 479, 41);
		textoname.setFont(new Font("Dialog", Font.PLAIN, 17));
		textoname.setColumns(10);
		frame.getContentPane().add(textoname);

		JLabel labelplace = new JLabel("\uC804\uD654\uBC88\uD638 : ");
		labelplace.setBounds(76, 333, 129, 52);
		labelplace.setHorizontalAlignment(SwingConstants.CENTER);
		labelplace.setFont(new Font("Dialog", Font.PLAIN, 20));
		frame.getContentPane().add(labelplace);

		textplace = new JTextField();
		textplace.setBounds(200, 340, 479, 41);
		textplace.setFont(new Font("Dialog", Font.PLAIN, 17));
		textplace.setColumns(10);
		frame.getContentPane().add(textplace);

		labelSearch = new JLabel("");
		labelSearch.setBounds(274, 40, 188, 54);
		labelSearch.setIcon(new ImageIcon("./Images/LFitem_icon7.jpg"));
		labelSearch.setHorizontalAlignment(SwingConstants.CENTER);
		frame.getContentPane().add(labelSearch);

		buttonOk = new JButton("\uCC3E\uC74C");
		buttonOk.setBounds(321, 412, 83, 41);
		buttonOk.setBackground(Color.orange);
		buttonOk.addActionListener(new ActionListener() {
			

			public void actionPerformed(ActionEvent e) {
				String username = textoname.getText();
				String name = textname.getText();
				String userpone = textplace.getText();
				int result = JOptionPane.showConfirmDialog(null,
						name + " ���� :  " + username + ", ��ȭ��ȣ : " + userpone + " �½��ϱ�?", "Confirm",
						JOptionPane.YES_NO_OPTION);
				if (result == JOptionPane.YES_OPTION) {
					
					int id = Integer.parseInt(name);
					d1.updateuser(username, userpone, id);
				} else {

				}

			}

		});
		buttonOk.setFont(new Font("���� ����", Font.BOLD, 20));
		
		frame.getContentPane().add(buttonOk);

		btnReturn = new JButton("");
		btnReturn.setIcon(new ImageIcon("./Images/backbtn_icon.PNG"));
		btnReturn.setContentAreaFilled(false);
		btnReturn.setBorderPainted(false);
		btnReturn.setBounds(12, 10, 83, 60);
		frame.getContentPane().add(btnReturn);
		frame.setTitle("Setting_SearchPage");
		frame.setBounds(100, 100, 755, 505);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);

		frame.setVisible(true);

		btnReturn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("�޴�â�� �����մϴ�");
				new Setting_menu(); // ���� �޴� Ŭ������ ����
			}
		});

	}
}