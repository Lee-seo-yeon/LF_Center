package LF_Center;

public class LF {
	private String id;
	private String name;
	private String chara;
	private String space;
	private String today;
	private String username;
	private String userpone;
	
	public LF(String id, String name, String chara, String space, String today, String username, String userpone) {
		super();
		this.id = id;
		this.name = name;
		this.chara = chara;
		this.space = space;
		this.today = today;
		this.username = username;
		this.userpone = userpone;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getChara() {
		return chara;
	}
	public void setChara(String chara) {
		this.chara = chara;
	}
	public String getSpace() {
		return space;
	}
	public void setSpace(String space) {
		this.space = space;
	}
	public String getToday() {
		return today;
	}
	public void setToday(String today) {
		this.today = today;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserpone() {
		return userpone;
	}
	public void setUserpone(String userpone) {
		this.userpone = userpone;
	}
	
	
}
	