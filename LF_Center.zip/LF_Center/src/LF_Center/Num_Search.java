package LF_Center;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Num_Search {

	private JFrame frame;
	private JTextField Search;
	private JButton btnReturn;

	public Num_Search() {
		initialize();
	}

	private void initialize() {

		String name = null;
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit()
				.getImage("./Images/logo.jpg"));
		frame.getContentPane().setBackground(new Color(255, 255, 224));
		frame.setTitle("SearchPage");
		frame.setBounds(100, 100, 755, 505);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);

		JButton btnSearch = new JButton("");
		btnSearch.setBounds(537, 10, 59, 57);
		btnSearch.setBorderPainted(false);
		btnSearch.setContentAreaFilled(false);

		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = Search.getText();
				JScrollPane scrollPane = new JScrollPane();
				scrollPane.setBounds(12, 90, 725, 86);
				frame.getContentPane().add(scrollPane);
				JTable Num_Searchtable = new JTable(); // ���̺�
				scrollPane.setViewportView(Num_Searchtable);
				Object[] colNames = new String[] { "�Ϸù�ȣ", "���湰��", "�������", "Ư¡" };
				db con = new db();
				DefaultTableModel model = new DefaultTableModel(colNames, 0) {
					public boolean isCellEditable(int i, int c) {
						return false;
					}
				};
				Object[] rowData = new Object[4];
				for (int i = 0, c = 1; i < con.getLF().size(); i++) {
					if (name.equals(con.getLF().get(i).getId())) {
						rowData[0] = con.getLF().get(i).getId();
						rowData[1] = con.getLF().get(i).getName();
						rowData[2] = con.getLF().get(i).getSpace();
						rowData[3] = con.getLF().get(i).getChara();
						model.addRow(rowData);
					}

				}

				Num_Searchtable.setModel(model);
				Num_Searchtable.setBackground(new Color(255,255,204)); //���̺� ��
				Num_Searchtable.setRowHeight(60); //�� ����
				//���� �ʺ�
				Num_Searchtable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
				Num_Searchtable.getColumnModel().getColumn(0).setPreferredWidth(80); 
				Num_Searchtable.getColumnModel().getColumn(1).setPreferredWidth(100);
				Num_Searchtable.getColumnModel().getColumn(2).setPreferredWidth(200);
				Num_Searchtable.getColumnModel().getColumn(3).setPreferredWidth(342);
				
				//��� ����
				DefaultTableCellRenderer tRenerer = new DefaultTableCellRenderer();
				tRenerer.setHorizontalAlignment(SwingConstants.CENTER);
				TableColumnModel tColModel = Num_Searchtable.getColumnModel();
				for(int i = 0; i < tColModel.getColumnCount(); i++) {
					tColModel.getColumn(i).setCellRenderer(tRenerer);
				}

			}
		});
		frame.getContentPane().setLayout(null);

		btnSearch.setIcon(new ImageIcon("./Images/Search_icon.PNG"));
		frame.getContentPane().add(btnSearch);

		Search = new JTextField();
		Search.setBounds(196, 10, 316, 48);
		Search.setFont(new Font("��������", Font.PLAIN, 17));
		frame.getContentPane().add(Search);
		Search.setColumns(10);
		
		btnReturn = new JButton("");
		btnReturn.setBounds(12, 10, 83, 60);
		btnReturn.setIcon(new ImageIcon("./Images/backbtn_icon.PNG"));
		btnReturn.setContentAreaFilled(false);
		btnReturn.setBorderPainted(false);
		frame.getContentPane().add(btnReturn);

		frame.setVisible(true);
		
		btnReturn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("�޴�â�� �����մϴ�");
				new Setting_menu(); //���� �޴� Ŭ������ ����
		    }               
	    });
	}
}