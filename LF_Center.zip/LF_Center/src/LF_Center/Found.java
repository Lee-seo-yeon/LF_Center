package LF_Center;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Found {

	private JFrame frame;
	private JTextField textoname;
	private JTextField textophone;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					Found window = new Found();
//					window.frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the application.
	 */
	public Found() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("Images/logo.jpg"));
		frame.getContentPane().setBackground(new Color(255, 255, 224));
		frame.getContentPane().setLayout(null);
		
		JLabel labeloname = new JLabel("\uC8FC\uC778\uC774\uB984 : ");
		labeloname.setHorizontalAlignment(SwingConstants.CENTER);
		labeloname.setFont(new Font("���� ����", Font.BOLD, 25));
		labeloname.setBounds(37, 74, 149, 52);
		frame.getContentPane().add(labeloname);
		
		textoname = new JTextField();
		textoname.setFont(new Font("Dialog", Font.PLAIN, 17));
		textoname.setColumns(10);
		textoname.setBounds(212, 85, 476, 41);
		frame.getContentPane().add(textoname);
		
		JLabel labelophone = new JLabel("\uC804\uD654\uBC88\uD638 : ");
		labelophone.setHorizontalAlignment(SwingConstants.CENTER);
		labelophone.setFont(new Font("���� ����", Font.BOLD, 25));
		labelophone.setBounds(37, 174, 149, 52);
		frame.getContentPane().add(labelophone);
		
		textophone = new JTextField();
		textophone.setHorizontalAlignment(SwingConstants.LEFT);
		textophone.setFont(new Font("Dialog", Font.PLAIN, 17));
		textophone.setColumns(10);
		textophone.setBounds(212, 185, 476, 41);
		frame.getContentPane().add(textophone);
		
		JButton buttonok = new JButton("\uC644\uB8CC");
		buttonok.setFont(new Font("���� ����", Font.BOLD, 20));
		buttonok.setBounds(341, 354, 83, 41);
		frame.getContentPane().add(buttonok);
		frame.setTitle("FoundPage");
		frame.setBounds(100, 100, 755, 505);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
//		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		frame.setVisible(true); //ȭ�� ���̰� �ϱ�
	}

}
