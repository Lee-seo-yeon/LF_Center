package LF_Center;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class menu {

	private JFrame frame;

	public menu() {
		initialize();
	}
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("./Images/logo.jpg"));
		frame.setTitle("MenuPage");
		frame.setBounds(100, 100, 755, 505);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.getContentPane().setLayout(null);
		
		JLabel lblmainmenu = new JLabel("mainmenu");
		lblmainmenu.setIcon(new ImageIcon("./Images/menu.png"));
		lblmainmenu.setBounds(0, 0, 749, 476);
		frame.getContentPane().add(lblmainmenu);
		 
		JButton btnCheck = new JButton("Check lost items");
		btnCheck.setBounds(524, 56, 199, 56);
		btnCheck.setBorderPainted(false);
		btnCheck.setContentAreaFilled(false);
		frame.getContentPane().add(btnCheck);
		
		JButton btnSearch = new JButton("Search lost items");
		btnSearch.setBounds(524, 129, 199, 56);
		btnSearch.setBorderPainted(false);
		btnSearch.setContentAreaFilled(false);
		frame.getContentPane().add(btnSearch);
		
		JButton btnFast = new JButton("fast lost items");
		btnFast.setBounds(524, 206, 199, 50);
		btnFast.setBorderPainted(false);
		btnFast.setContentAreaFilled(false);
		frame.getContentPane().add(btnFast);
		
		JButton btnAdd = new JButton("Add lost items");
		btnAdd.setBounds(524, 281, 199, 56);
		btnAdd.setBorderPainted(false);
		btnAdd.setContentAreaFilled(false);
		frame.getContentPane().add(btnAdd);
		
		JButton btnsetting = new JButton("Setting");
		btnsetting.setContentAreaFilled(false);
		btnsetting.setBorderPainted(false);
		btnsetting.setBounds(524, 353, 199, 50);
		frame.getContentPane().add(btnsetting);
		
		JButton btnReturn = new JButton("Return");
		btnReturn.setBounds(0, 0, 60, 50);
		btnReturn.setBorderPainted(false);
		btnReturn.setContentAreaFilled(false);
		frame.getContentPane().add(btnReturn);
		
		frame.setVisible(true);
		
		btnCheck.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("�нǹ� Ȯ��â�� �����մϴ�");
				new Check();
		    }               
	    });
		
		btnSearch.addActionListener(new ActionListener() {
	        // ������� ��ư "�нǹ� ��ȸ"�� ��ư�� �������� �нǹ� ��ȸ�� �̵��ϴ� �ൿ�� ����
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("�нǹ� ��ȸâ�� �����մϴ�");
				new Search();
		    }               
	    });
		
		btnFast.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("�нǹ� ���â�� �����մϴ�");
				new Fast();
		    }               
	    });
		
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("�нǹ� �߰�â�� �����մϴ�");
				new Add();
		    }               
	    });
		
		btnsetting.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("����â�� �����մϴ�");
				new Setting_menu();
		    }               
	    });
			
		btnReturn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("����â�� �����մϴ�");
				new first();
		    }               
	    });
	}
}