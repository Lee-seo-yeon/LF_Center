package LF_Center;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Information {

	private JFrame frame;
	private JTextField textname;
	private JTextField textspace;
	private JTextField textchara;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					Information window = new Information();
//					window.frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the application.
	 */
	public Information() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("DImages/logo.jpg"));
		frame.getContentPane().setBackground(new Color(255, 255, 224));
		frame.setTitle("InformationPage");
		frame.setBounds(100, 100, 755, 505);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
//		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel labelname = new JLabel("\uC774\uB984 : ");
		labelname.setHorizontalAlignment(SwingConstants.CENTER);
		labelname.setFont(new Font("���� ����", Font.BOLD, 25));
		labelname.setBounds(51, 53, 92, 52);
		frame.getContentPane().add(labelname);
		
		textname = new JTextField();
		textname.setFont(new Font("Dialog", Font.PLAIN, 17));
		textname.setColumns(10);
		textname.setBounds(150, 64, 559, 41);
		frame.getContentPane().add(textname);
		
		JLabel labelspace = new JLabel("\uBC1C\uACAC\uC7A5\uC18C : ");
		labelspace.setHorizontalAlignment(SwingConstants.CENTER);
		labelspace.setFont(new Font("���� ����", Font.BOLD, 25));
		labelspace.setBounds(0, 135, 149, 52);
		frame.getContentPane().add(labelspace);
		
		textspace = new JTextField();
		textspace.setFont(new Font("Dialog", Font.PLAIN, 17));
		textspace.setColumns(10);
		textspace.setBounds(150, 135, 559, 41);
		frame.getContentPane().add(textspace);
		
		JLabel labelchara = new JLabel("\uD2B9\uC9D5 : ");
		labelchara.setHorizontalAlignment(SwingConstants.CENTER);
		labelchara.setFont(new Font("���� ����", Font.BOLD, 25));
		labelchara.setBounds(51, 218, 92, 41);
		frame.getContentPane().add(labelchara);
		
		textchara = new JTextField();
		textchara.setFont(new Font("Dialog", Font.PLAIN, 17));
		textchara.setColumns(10);
		textchara.setBounds(150, 218, 559, 131);
		frame.getContentPane().add(textchara);
		
		JButton buttonDelete = new JButton("\uC0AD\uC81C");
		buttonDelete.setFont(new Font("���� ����", Font.BOLD, 20));
		buttonDelete.setBounds(258, 394, 83, 41);
		frame.getContentPane().add(buttonDelete);
		
		JButton buttonok = new JButton("\uCC3E\uC74C");
		buttonok.setFont(new Font("���� ����", Font.BOLD, 20));
		buttonok.setBounds(399, 394, 83, 41);
		frame.getContentPane().add(buttonok);
		frame.setVisible(true); //ȭ�� ���̰� �ϱ�
		
		buttonok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("�����մϴ�");
				new Found(); 
		    }               
	    });
	}
}
