package LF_Center;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Setting_menu {

	private JFrame frame;

	public Setting_menu() {
		initialize();
	}
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("./Images/logo.jpg"));
		frame.setTitle("Setting_menuPage");
		frame.setBounds(100, 100, 755, 505);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.getContentPane().setLayout(null);
		
		JLabel lblsetting_menu = new JLabel("setting_menu");
		lblsetting_menu.setBounds(-12, -27, 778, 519);
		lblsetting_menu.setIcon(new ImageIcon("./Images/setting_menu.PNG"));
		frame.getContentPane().add(lblsetting_menu);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.setBounds(261, 123, 201, 52);
		btnDelete.setBorderPainted(false);
		btnDelete.setContentAreaFilled(false);
		frame.getContentPane().add(btnDelete);
		
		JButton btnnumSearch = new JButton("numSearch");
		btnnumSearch.setBounds(261, 206, 201, 52);
		btnnumSearch.setBorderPainted(false);
		btnnumSearch.setContentAreaFilled(false);
		frame.getContentPane().add(btnnumSearch);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.setBounds(268, 280, 194, 52);
		btnSearch.setBorderPainted(false);
		btnSearch.setContentAreaFilled(false);
		frame.getContentPane().add(btnSearch);
		
		JButton btnReturn = new JButton("Return");
		btnReturn.setBounds(25, 26, 43, 41);
		btnReturn.setBorderPainted(false);
		btnReturn.setContentAreaFilled(false);
		frame.getContentPane().add(btnReturn);
		
		frame.setVisible(true);
		
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("���� - �нǹ� ����â�� �����մϴ�");
				new Setting_Delete();
		    }               
	    });
		
		btnnumSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("���� - �ϷĹ�ȣ ��ȸâ�� �����մϴ�");
				new Num_Search();
		    }               
	    });
		
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("���� - �нǹ���ȸâ�� �����մϴ�");
				new Setting_Search();
		    }               
	    });
		
		btnReturn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("�޴�â�� �����մϴ�");
				new menu(); //�޴� Ŭ������ ����
		    }               
	    });
		
	}
}