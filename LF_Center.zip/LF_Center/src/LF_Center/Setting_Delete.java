package LF_Center;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Setting_Delete {

	private JFrame frame;
	private JTextField textnum;

	public Setting_Delete() {
		initialize();
	}

	private void initialize() {
		db d1 = new db();
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 255, 224));
		frame.getContentPane().setLayout(null);

		JLabel lblDelete = new JLabel("");
		lblDelete.setBounds(277, 26, 188, 54);
		lblDelete.setHorizontalAlignment(SwingConstants.CENTER);
		lblDelete.setIcon(new ImageIcon("./Images/LFitem_icon_8.jpg"));
		frame.getContentPane().add(lblDelete);

		JLabel labelDelete = new JLabel("\uC77C\uB828\uBC88\uD638 : ");
		labelDelete.setBounds(214, 161, 148, 65);
		labelDelete.setHorizontalAlignment(SwingConstants.CENTER);
		labelDelete.setFont(new Font("Dialog", Font.BOLD, 25));
		frame.getContentPane().add(labelDelete);

		textnum = new JTextField();
		textnum.setBounds(374, 175, 113, 41);
		textnum.setFont(new Font("Dialog", Font.PLAIN, 17));
		textnum.setColumns(10);
		frame.getContentPane().add(textnum);

		JButton btnDelete = new JButton("\uC0AD\uC81C");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				int id = Integer.parseInt(textnum.getText());

				int result = JOptionPane.showConfirmDialog(null, "\""+id +"\" ���� ���� �Ͻðڽ��ϱ�?", "Confirm", JOptionPane.YES_NO_OPTION);
				if (result == JOptionPane.YES_OPTION) {
					d1.del(id);
					JOptionPane.showMessageDialog(null, "���� �Ϸ�!!");
					new menu();
				}
			}
		});
		btnDelete.setFont(new Font("���� ����", Font.BOLD, 20));
		btnDelete.setBounds(329, 304, 83, 41);
		btnDelete.setBackground(Color.orange);

		frame.getContentPane().add(btnDelete);

		JButton btnReturn = new JButton("");
		btnReturn.setIcon(new ImageIcon("./Images/backbtn_icon.PNG"));
		btnReturn.setContentAreaFilled(false);
		btnReturn.setBorderPainted(false);
		btnReturn.setBounds(12, 10, 83, 60);
		frame.getContentPane().add(btnReturn);
		frame.setTitle("Setting_DeletePage");
		frame.setBounds(100, 100, 755, 505);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);

		frame.setVisible(true);

		btnReturn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("�޴�â�� �����մϴ�");
				new Setting_menu(); // ���� �޴� Ŭ������ ����
			}
		});
	}

}