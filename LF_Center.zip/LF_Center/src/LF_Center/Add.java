package LF_Center;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Add {
	private JFrame frame;
	private JTextField textname;
	private JTextField textplace;
	private JTextField textChar;
	private JButton btnAdd;
	private JButton btnReturn;

	public Add() {
		initialize();
	}
	private void initialize() {
		db d1 = new db();
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 255, 224));
		frame.getContentPane().setLayout(null);

		JLabel lblAdd_item = new JLabel("");
		lblAdd_item.setBounds(275, 10, 194, 52);
		lblAdd_item.setIcon(new ImageIcon("./Images/menu_icon2.jpg"));
		frame.getContentPane().add(lblAdd_item);

		JLabel lblname = new JLabel("\uC2B5\uB4DD\uBB3C\uBA85 :");
		lblname.setBounds(7, 92, 144, 52);
		lblname.setHorizontalAlignment(SwingConstants.CENTER);
		lblname.setFont(new Font("���� ����", Font.BOLD, 25));
		frame.getContentPane().add(lblname);

		textname = new JTextField();
		textname.setBounds(153, 103, 559, 41);
		textname.setFont(new Font("��������", Font.PLAIN, 17));
		frame.getContentPane().add(textname);
		textname.setColumns(10);

		JLabel lblplace = new JLabel("\uC2B5\uB4DD\uC7A5\uC18C :");
		lblplace.setBounds(7, 165, 149, 52);
		lblplace.setFont(new Font("���� ����", Font.BOLD, 25));
		lblplace.setHorizontalAlignment(SwingConstants.CENTER);
		frame.getContentPane().add(lblplace);

		textplace = new JTextField();
		textplace.setBounds(153, 176, 559, 41);
		textplace.setFont(new Font("��������", Font.PLAIN, 17));
		frame.getContentPane().add(textplace);
		textplace.setColumns(10);

		JLabel lblChar = new JLabel("\uD2B9\uC9D5 : ");
		lblChar.setFont(new Font("���� ����", Font.BOLD, 25));
		lblChar.setHorizontalAlignment(SwingConstants.CENTER);
		lblChar.setBounds(64, 237, 92, 41);
		frame.getContentPane().add(lblChar);

		textChar = new JTextField();
		textChar.setFont(new Font("��������", Font.PLAIN, 17));
		textChar.setColumns(10);
		textChar.setBounds(153, 237, 559, 165);
		frame.getContentPane().add(textChar);

		btnAdd = new JButton("\uCD94\uAC00");
		btnAdd.setIcon(null);
		btnAdd.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				String name = textname.getText();
				String chara = textChar.getText();
				String space = textplace.getText();

				if (name.equals("")) {
					JOptionPane.showMessageDialog(null, "�нǹ��� �̸��� �ۼ����� �ʾҽ��ϴ�.");
				} else if (chara.equals("")) {
					JOptionPane.showMessageDialog(null, "�нǹ��� Ư¡�� �ۼ����� �ʾҽ��ϴ�.");
				} else if (space.equals("")) {
					JOptionPane.showMessageDialog(null, "�нǹ��� ��Ұ� �ۼ����� �ʾҽ��ϴ�.");
				} else {
					int result = JOptionPane.showConfirmDialog(null,
							name + " �нǹ��� Ư¡ :  " + chara + ", ��� : " + space + "�� �½��ϱ�?", "Confirm",
							JOptionPane.YES_NO_OPTION);
					if (result == JOptionPane.YES_OPTION) {
						JOptionPane.showMessageDialog(null, "�нǹ� �߰� �Ϸ�!");
						d1.dbupdate(name, space, chara);
						new menu(); // �޴� Ŭ������ ����
					} else {
						
					}
				}
			}
		});
		btnAdd.setFont(new Font("���� ����", Font.BOLD, 20));
		btnAdd.setBounds(331, 425, 74, 41);
		btnAdd.setBackground(Color.orange);

		frame.getContentPane().add(btnAdd);
		
		btnReturn = new JButton("");
		btnReturn.setIcon(new ImageIcon("./Images/backbtn_icon.PNG"));
		btnReturn.setContentAreaFilled(false);
		btnReturn.setBorderPainted(false);
		btnReturn.setBounds(7, 10, 83, 60);
		
		frame.getContentPane().add(btnReturn);
		frame.setTitle("AddPage");
		frame.setBounds(100, 100, 755, 505);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);

		frame.setVisible(true);

		btnReturn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("�޴�â�� �����մϴ�");
				new menu(); //�޴� Ŭ������ ����
		    }               
	    });
	}

}