package LF_Center;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.Customizer;

public class Check {

	private JFrame frame;
	private JTable dbtable;
	private JTable Checktable;
	
	public Check() {
		initialize();
	}
	private void initialize() {
		
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("./Images/logo.jpg"));
		frame.getContentPane().setBackground(new Color(255, 255, 224));
		frame.getContentPane().setLayout(null);
		
		JLabel lblLF_item = new JLabel("");
		lblLF_item.setBounds(266, 10, 194, 44);
		lblLF_item.setIcon(new ImageIcon("./Images/menu_icon1.jpg"));
		
		frame.getContentPane().add(lblLF_item);
		
		JScrollPane scrollPaneCheck = new JScrollPane();
		scrollPaneCheck.setBounds(12, 89, 725, 377);
		frame.getContentPane().add(scrollPaneCheck);
		
		//�нǹ� Ȯ�� â�� �нǹ� ���̺�
		Checktable = new JTable(); //���̺�
		scrollPaneCheck.setViewportView(Checktable);
		Object[] colNames = new String[] {"�Ϸù�ȣ","���湰��","�������","Ư¡"};
		db con = new db();
		        DefaultTableModel model = new DefaultTableModel(colNames, 0) {
		        	public boolean isCellEditable(int i, int c) {
		        			return false;
		            }
		        };
				Object[] rowData = new Object[4];
				
				for (int i = 0, c = 1; i < con.getLF().size(); i++) {
					if(con.getLF().get(i).getUsername()==null) {
						rowData[0] = con.getLF().get(i).getId();
						rowData[1] = con.getLF().get(i).getName();
			            rowData[2] = con.getLF().get(i).getSpace();
			            rowData[3] = con.getLF().get(i).getChara();
			            model.addRow(rowData);
					}
				}
				
					Checktable.setModel(model);
					Checktable.setBackground(new Color(255,255,204)); //���̺� ��
					Checktable.setRowHeight(30); //�� ����
					//���� �ʺ�
					Checktable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
					
					JButton btnReturn = new JButton("Return");
					btnReturn.setIcon(new ImageIcon("./Images/backbtn_icon.PNG"));
					btnReturn.setBounds(12, 10, 84, 60);
					btnReturn.setBorderPainted(false);
					btnReturn.setContentAreaFilled(false);
					
					frame.getContentPane().add(btnReturn);
					Checktable.getColumnModel().getColumn(0).setPreferredWidth(80); 
					Checktable.getColumnModel().getColumn(1).setPreferredWidth(100);
					Checktable.getColumnModel().getColumn(2).setPreferredWidth(200);
					Checktable.getColumnModel().getColumn(3).setPreferredWidth(342);
					
					//��� ����
					DefaultTableCellRenderer tRenerer = new DefaultTableCellRenderer();
					tRenerer.setHorizontalAlignment(SwingConstants.CENTER);
					TableColumnModel tColModel = Checktable.getColumnModel();
					for(int i = 0; i < tColModel.getColumnCount(); i++) {
						tColModel.getColumn(i).setCellRenderer(tRenerer);
					}
		
		
		frame.setTitle("CheckPage"); //������ �̸�
		frame.setBounds(100, 100, 755, 505); //â ũ��
		frame.setLocationRelativeTo(null); //��� ��ġ
		frame.setResizable(false); //â �ø��� �Ұ�
		frame.setVisible(true); //ȭ�� ���̰� �ϱ�
		
		btnReturn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("�޴�â�� �����մϴ�");
				new menu();
		    }               
	    });
	}
}
