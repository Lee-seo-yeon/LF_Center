package LF_Center;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.JButton;

public class Fast {

	private JFrame frame;
	private JTable Fasttable;
	private JButton btnReturn;

	public Fast() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("./Images/logo.jpg"));
		frame.getContentPane().setBackground(new Color(255, 255, 224));
		frame.getContentPane().setLayout(null);
		
		JLabel lblFast_item = new JLabel("");
		lblFast_item.setBounds(280, 10, 188, 56);
		lblFast_item.setIcon(new ImageIcon("./Images/LFitem_icon7.jpg"));
		frame.getContentPane().add(lblFast_item);
		
		JScrollPane scrollPaneFast = new JScrollPane();
		scrollPaneFast.setBounds(12, 130, 725, 336);
		frame.getContentPane().add(scrollPaneFast);
		
		Fasttable = new JTable(); //�нǹ� ��� ���̺�
		scrollPaneFast.setViewportView(Fasttable);
		Object[] colNames = new String[] {"�Ϸù�ȣ","���湰��","�������","Ư¡","�����̸�","���� ��ȭ��ȣ"};
		db con = new db();
		        DefaultTableModel model = new DefaultTableModel(colNames, 0) {
		        	public boolean isCellEditable(int i, int c) {
		        			return false;
		            }
		        };
				Object[] rowData = new Object[7];
				
				for (int i = 0, c = 1; i < con.getLF().size(); i++) {
					if(con.getLF().get(i).getUsername()!=null) {
						rowData[0] = con.getLF().get(i).getId();
						rowData[1] = con.getLF().get(i).getName();
			            rowData[2] = con.getLF().get(i).getSpace();
			            rowData[3] = con.getLF().get(i).getChara();
			            rowData[4] = con.getLF().get(i).getUsername();
			            rowData[5] = con.getLF().get(i).getUserpone();
			            model.addRow(rowData);
					}
				}
					Fasttable.setModel(model);
					Fasttable.setBackground(new Color(255,255,204)); //���̺� ��
					Fasttable.setRowHeight(30); //�� ũ��
					
					DefaultTableCellRenderer tRenerer = new DefaultTableCellRenderer();
					tRenerer.setHorizontalAlignment(SwingConstants.CENTER);
					TableColumnModel tColModel = Fasttable.getColumnModel();
					for(int i = 0; i < tColModel.getColumnCount(); i++) {
						tColModel.getColumn(i).setCellRenderer(tRenerer);
					}
		
		scrollPaneFast.setColumnHeaderView(Fasttable);
		
		btnReturn = new JButton("");
		btnReturn.setBounds(12, 10, 83, 60);
		btnReturn.setIcon(new ImageIcon("./Images/backbtn_icon.PNG"));
		btnReturn.setContentAreaFilled(false);
		btnReturn.setBorderPainted(false);
		frame.getContentPane().add(btnReturn);
		
		JLabel lblSel = new JLabel("");
		lblSel.setIcon(new ImageIcon("./Images/Sell.jpg"));
		lblSel.setBounds(12, 102, 725, 30);
		frame.getContentPane().add(lblSel);
		frame.setTitle("FastPage");
		frame.setBounds(100, 100, 755, 505);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		
		frame.setVisible(true);
		
		btnReturn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("�޴�â�� �����մϴ�");
				new menu(); //�޴� Ŭ������ ����
		    }               
	    });
	}
}
