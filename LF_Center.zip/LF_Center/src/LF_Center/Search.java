package LF_Center;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Search {

	private JFrame frame;
	private JTextField Search;
	private JButton btnReturn;

	public Search() {
		initialize();
	}

	private void initialize() {

		String name = null;
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit()
				.getImage("./Images/logo.jpg"));
		frame.getContentPane().setBackground(new Color(255, 255, 224));
		frame.setTitle("SearchPage");
		frame.setBounds(100, 100, 755, 505);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.getContentPane().setLayout(null);

		JButton btnSearch = new JButton("");
		btnSearch.setBounds(554, 10, 59, 57);
		btnSearch.setBorderPainted(false);
		btnSearch.setContentAreaFilled(false);
		
		Search = new JTextField();
		Search.setBounds(207, 10, 316, 48);
		Search.setFont(new Font("��������", Font.PLAIN, 17));
		frame.getContentPane().add(Search);
		Search.setColumns(10);
		
		btnReturn = new JButton("");
		btnReturn.setIcon(new ImageIcon("./Images/backbtn_icon.PNG"));
		btnReturn.setContentAreaFilled(false);
		btnReturn.setBorderPainted(false);
		btnReturn.setBounds(12, 10, 83, 60);
		frame.getContentPane().add(btnReturn);

		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = Search.getText();
				JScrollPane scrollPane = new JScrollPane();
				scrollPane.setBounds(12, 90, 725, 377);
				frame.getContentPane().add(scrollPane);
				JTable Searchtable = new JTable(); // ���̺�
				scrollPane.setViewportView(Searchtable);
				Object[] colNames = new String[] { "�Ϸù�ȣ", "���湰��", "�������", "Ư¡" };
				db con = new db();
				DefaultTableModel model = new DefaultTableModel(colNames, 0) {
					public boolean isCellEditable(int i, int c) {
						return false;
					}
				};
				Object[] rowData = new Object[4];
				for (int i = 0, c = 1; i < con.getLF().size(); i++) {
					if (name.equals(con.getLF().get(i).getName())) {
						rowData[0] = con.getLF().get(i).getId();
						rowData[1] = con.getLF().get(i).getName();
						rowData[2] = con.getLF().get(i).getSpace();
						rowData[3] = con.getLF().get(i).getChara();
						model.addRow(rowData);
					}

				}

				Searchtable.setModel(model);
				Searchtable.setModel(model);
				Searchtable.setBackground(new Color(255,255,204)); //���̺� ��
				Searchtable.setRowHeight(30); //�� ����
				//���� �ʺ�
				Searchtable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
				Searchtable.getColumnModel().getColumn(0).setPreferredWidth(80); 
				Searchtable.getColumnModel().getColumn(1).setPreferredWidth(100);
				Searchtable.getColumnModel().getColumn(2).setPreferredWidth(200);
				Searchtable.getColumnModel().getColumn(3).setPreferredWidth(342);
				
				//��� ����
				DefaultTableCellRenderer tRenerer = new DefaultTableCellRenderer();
				tRenerer.setHorizontalAlignment(SwingConstants.CENTER);
				TableColumnModel tColModel = Searchtable.getColumnModel();
				for(int i = 0; i < tColModel.getColumnCount(); i++) {
					tColModel.getColumn(i).setCellRenderer(tRenerer);
				}

			}
		});

		btnSearch.setIcon(new ImageIcon("./Images/Search_icon.PNG"));
		frame.getContentPane().add(btnSearch);

		frame.setVisible(true);
		
		btnReturn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("�޴�â�� �����մϴ�");
				new menu(); //�޴� Ŭ������ ����
		    }               
	    });
	}
}
